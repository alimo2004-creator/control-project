"""
Target Velocity Profiler based on track curvature.
Calculates maximum safe cornering speeds subject to lateral acceleration limits.
"""

import math  # noqa: F401


class VelocityProfiler:
    """Generates target speed profiles based on track curvature or precomputed data."""

    def __init__(self, default_speed=4.0, max_speed=8.0, max_lat_accel=5.0):
        self.default_speed = default_speed
        self.max_speed = max_speed
        self.max_lat_accel = max_lat_accel

    def compute_target_speed(self, kappa, fallback_speed=None):
        """Calculates curvature-limited velocity: v_max = sqrt(a_lat_max / |kappa|)."""
        if fallback_speed is None:
            fallback_speed = self.default_speed

        # Invalid curvature (NaN / inf): fall back to the requested speed
        if kappa is None or not math.isfinite(kappa):
            return float(min(fallback_speed, self.max_speed))

        abs_kappa = abs(kappa)
        if abs_kappa < 1e-6:
            return float(self.max_speed)  # straight: no lateral limit

        v_curve = math.sqrt(self.max_lat_accel / abs_kappa)
        return float(min(v_curve, self.max_speed))
    