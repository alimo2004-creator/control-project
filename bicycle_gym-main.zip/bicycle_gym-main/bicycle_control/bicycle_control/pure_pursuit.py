"""
High-Level Lateral Steering Controller: Geometric Pure Pursuit.
Calculates steering curvature from lookahead arc geometry.
"""

import math  # noqa: F401
import numpy as np  # noqa: F401


class PurePursuitController:
    """Adaptive Pure Pursuit lateral controller."""

    def __init__(self, wheelbase=1.25, kv=0.25, l_min=0.8, l_max=2.5,
                 max_steer_rad=math.radians(35.0)):
        self.L = wheelbase
        self.kv = kv
        self.l_min = l_min
        self.l_max = l_max
        self.max_steer_rad = max_steer_rad

    def compute_lookahead(self, v):
        """Adaptive lookahead distance: Ld = clip(kv * v + l_min, l_min, l_max)."""
        # TODO: Milestone 5.3 Step 1 — Adaptive Lookahead Horizon
        # The car looks further ahead at higher speeds to plan smoother turns.
        # Implement the speed-scaled lookahead formula and clamp it to the allowed range.

        v = max(float(v), 0.0)

        lookahead = self.kv * v + self.l_min

        return float(np.clip(
            lookahead,
            self.l_min,
            self.l_max
        ))

    def find_target_waypoint(self, x, y, path_points, lookahead):
        """Searches along path for the target waypoint at lookahead distance."""
        # TODO: Milestone 5.3 Step 2 — Target Waypoint Selection
        # This selects the goal point the car will steer toward.
        # Find the nearest waypoint on the path, then walk forward until
        # you reach one that is at least 'lookahead' meters away.

        path_points = np.asarray(path_points, dtype=float)

        if len(path_points) == 0:
            return 0, (x, y, 0.0)

        # Find the waypoint nearest to the vehicle
        distances = np.hypot(
            path_points[:, 0] - x,
            path_points[:, 1] - y
        )

        nearest_idx = int(np.argmin(distances))
        n = len(path_points)

        # Search forward through the path
        for k in range(n):
            idx = (nearest_idx + k) % n

            distance = math.hypot(
                path_points[idx, 0] - x,
                path_points[idx, 1] - y
            )

            if distance >= lookahead:
                return idx, tuple(path_points[idx])

        # Fallback if no waypoint reaches the requested distance
        return nearest_idx, tuple(path_points[nearest_idx])

    def compute_steering(self, x, y, yaw, target_pt, lookahead):
        """Computes steering angle in radians using Pure Pursuit geometry."""
        # TODO: Milestone 5.3 Steps 3 & 4 — Coordinate Transformation & Arc Law
        # This is the core of Pure Pursuit: transform the target into the vehicle’s
        # local frame, then use the arc geometry formula to compute the steering angle.

        if target_pt is None:
            return 0.0

        target_pt = np.asarray(target_pt, dtype=float)

        if target_pt.shape[0] < 2:
            return 0.0

        # Difference between target point and vehicle position
        dx = target_pt[0] - x
        dy = target_pt[1] - y

        # Transform target point from world frame
        # to vehicle frame:
        # local x = forward
        # local y = left
        local_x = math.cos(yaw) * dx + math.sin(yaw) * dy
        local_y = -math.sin(yaw) * dx + math.cos(yaw) * dy

        # Actual distance to target
        actual_lookahead = max(
            math.hypot(local_x, local_y),
            1e-6
        )

        # Angle from vehicle heading to target point
        alpha = math.atan2(local_y, local_x)

        # Pure Pursuit steering law
        steering = math.atan2(
            2.0 * self.L * math.sin(alpha),
            actual_lookahead
        )

        # Steering saturation
        steering = np.clip(
            steering,
            -self.max_steer_rad,
            self.max_steer_rad
        )

        return float(steering)
